from flask import Flask, redirect, url_for, session
from auth import bp as auth_bp
from itinerary import itinerary_bp

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.register_blueprint(auth_bp)
app.register_blueprint(itinerary_bp)

@app.route('/')
def home():
    return redirect(url_for('auth.login'))

if __name__ == '__main__':
    app.run(debug=True)
