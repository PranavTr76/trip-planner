import pandas as pd
from flask import Blueprint, render_template, request

itinerary_bp = Blueprint('itinerary', __name__)

# Load the CSV data
data = pd.read_csv("D:/VS Practice/project 2/dataset/Filtered_output.csv")

@itinerary_bp.route('/dashboard', methods=['GET'])
def dashboard():
    return render_template('dashboard.html')

@itinerary_bp.route('/accommodation/<city>', methods=['GET'])
def accommodation(city):
    # Filter accommodations based on the city
    accommodations = data[data['City'] == city].head(5)  # Get first 5 accommodations
    return render_template('accommodation.html', accommodations=accommodations)

@itinerary_bp.route('/search', methods=['GET', 'POST'])
def search():
    results = []
    if request.method == 'POST':
        city = request.form.get('city')
        # Filter results based on the city input and get top 4 unique places
        results = data[data['City'].str.contains(city, case=False)]
        results = results.drop_duplicates(subset=['Place']).head(4)
    
    # Implement pagination
    page = request.args.get('page', 1, type=int)
    per_page = 10
    total = len(results)
    start = (page - 1) * per_page
    end = start + per_page
    results = results[start:end]
    
    return render_template('results.html', results=results, total=total, page=page, per_page=per_page)
