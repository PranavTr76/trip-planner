from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from werkzeug.security import generate_password_hash, check_password_hash

bp = Blueprint('auth', __name__)

# Simple in-memory user storage
users = {}

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Please fill all fields')
        elif email in users and check_password_hash(users[email]['password'], password):
            session['user_id'] = email
            return redirect(url_for('itinerary.search'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not email or not password or not confirm_password:
            flash('Please fill all fields')
        elif password != confirm_password:
            flash('Passwords do not match')
        elif email in users:
            flash('Email already exists')
        else:
            users[email] = {
                'password': generate_password_hash(password)
            }
            session['user_id'] = email
            return redirect(url_for('itinerary.search'))
    return render_template('register.html')

@bp.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('auth.login'))
